Rise & Glory - uniwersalne assety UI

item_slot.png
- pojedynczy slot przedmiotu
- plecak, loot, ekwipunek, nagrody

shop_item_slot.png
- slot przedmiotu z wydzielonym dolnym polem
- sklep, zbrojmistrz, handlarz; dolne pole na cene

equipment_slot.png
- pionowy slot ekwipunku z miejscem na naglowek
- Bron, Pancerz, Helm, Buty, Rekawice, Amulet, Pierscienie

helper_slot.png
- pionowy slot postaci/NPC
- Pomocnicy, najemnicy, towarzysze

resource_row.png
- poziomy wiersz: ikona + opis + wartosc
- prowiant, materialy, zasoby, koszty, wymagania

quest_row.png
- poziomy wiersz z okraglym slotem po lewej i polem akcji po prawej
- aktywne Questy, historia, kontrakty, zadania

service_row.png
- poziomy wiersz z kilkoma sekcjami
- Tawerna, Ratusz, Gildia, uslugi, oferty

details_panel.png
- pionowy panel z miejscem na duza ikone/grafike i opis
- szczegoly przedmiotu, NPC, uslugi, nagrody

portrait_frame.png
- duza pionowa rama portretowa
- bohater, kupiec, kowal, karczmarz, NPC

large_content_panel.png
- duzy glowny panel zawartosci z polem naglowka
- ekran sklepu, miasta, lokacji, lista przedmiotow/uslug
